import hashlib

def read_file(file_name):
    fo = open(file_name, "r")
    password_list = fo.readlines()
    for i in range(len(password_list)):
        if i != len(password_list) - 1:
            password_list[i] = password_list[i][0:-1]
    fo.close()
    return password_list


contents = read_file("testyou.txt")
hashes = [hashlib.sha256(bytes(item, 'utf-8')).digest() for item in contents]

fo = open("testyou-hash.txt", "w")

for item in hashes:
    fo.write(str(item) + "\n")

fo.write(str(hashlib.sha256(bytes("111", 'utf-8')).digest()))
fo.close()
